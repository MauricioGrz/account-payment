## Module <mass_price_update>

#### 23.11.2022
#### Version 15.0.1.0.0
#### ADD

- Initial commit for Mass Price Update
